Some default SQL for GPDB
