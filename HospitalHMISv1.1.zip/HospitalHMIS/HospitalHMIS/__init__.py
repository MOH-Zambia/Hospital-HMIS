"""
Package for HospitalHMIS.
"""
